
let count = 0;
/* -------------------------- bouton d'acceptation -------------------------- */
let submit = document.getElementById("submit");
submit.addEventListener("click", function (event) {
    event.preventDefault();     
});
submit.addEventListener("click", createLi);

/* -------------------------- création de la liste -------------------------- */
let list = document.createElement("ul");
list.setAttribute("id", "list");
document.getElementById("wrapper").appendChild(list);

/* -------- fonction pour chaque clic, création d'un nouvel élément dans la liste -------- */
function createLi() {
    /* -------------- recuperation du texte introduit dans l'input -------------- */
    let valeur = document.getElementById("name").value;

    /* -------------- condition pour submit interdire un champ vide ------------- */
    if (valeur == "" || valeur == " " ) {
        alert("attention, champs vide!");
    }
    else{
        let listItem = document.createElement("li");
        let deleteItem = document.createElement("button");

        listItem.setAttribute("id", "listItem");
        listItem.innerText = valeur;
        deleteItem.setAttribute("id", "delItem");
        deleteItem.innerText = "X";
        
        count += 1; // compteur incremental pour l'ombrage
        
        /* ------- ajouts des éléments dans la liste + un bouton de suppression ------ */
        document.getElementById("list").appendChild(listItem).appendChild(deleteItem);
        
        list.style.boxShadow = "8px 12px 20px 6px grey";
        
        /* ----------- evenement de suppression d'un élément dans la liste ---------- */
        deleteItem.addEventListener("click", function () {
            listItem.parentNode.removeChild(listItem); 
            count -= 1; // compteur décremental pour l'ombrage
            if (count < 1) {
                list.style.boxShadow = ""; // si le compteur est a 0 on retire la box shadow de l'UL
            }
        });

        /* --------------------------- vide l'input field --------------------------- */
        document.getElementById("name").value = "";   
    }
}



